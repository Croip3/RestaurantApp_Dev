# README Restaurant_Dev App

## First steps
- https://github.com/Croip3/RestaurantApp_Dev.git
- git clone
- cd in RestaurantApp_Dev
- npm install
- npm install firebase
- npm install react-bootstrap
- npm install react-router-dom


## Authentication 
- Firebase Account
- Firebase E-Mail/Password Authentication aktivieren 
- firebase_conifig.js eigene Daten eintragen

## Noch zu lösen
- Bestätigung per Mail, damit keine Quatsch E-Mails sich anmelden können
- Schutz gegen Spam
- Bedingungen für Anmeldungen festlegen und diese mit Popup anzeigen, wenn etwas falsch eingegeben wird
- Ein kann, kein Muss: 2 Flows einmal mit Verification und einmal Account durch E-Mail 
