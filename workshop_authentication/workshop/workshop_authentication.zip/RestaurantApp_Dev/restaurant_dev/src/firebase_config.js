import { initializeApp } from "firebase/app";

const firebaseConfig = {

  {/* Hier steht noch nichts, weil die Daten nicht offen sein sollten, wenn die ganze Sache 
  auf Github landet */}
  };
  